import {createStore} from 'redux';
import {rootReducer} from '../reducers/root.reducer';
// createStore(reducer,defStoreData)

var storeData = {
    products:[],
    users:[]
}

createStore(rootReducer,storeData)