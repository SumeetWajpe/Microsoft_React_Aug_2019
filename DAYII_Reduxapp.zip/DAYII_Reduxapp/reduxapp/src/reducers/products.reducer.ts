export function products(defStore = []) {
    console.log('Within products reducer !');
    return defStore; // return a new/updated store !
}