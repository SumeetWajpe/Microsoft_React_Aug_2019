import React from 'react';
import Product from './product.model';
export  class ProductComponent extends
    React.Component<any>{
    render() {
        return <React.Fragment>
            <h1> {this.props.prodDetails.title} </h1>     
            <h3>Price : {this.props.prodDetails.price}</h3>
            <h3>Rating : {this.props.prodDetails.rating}</h3>
        </React.Fragment>
    }
}
export const PI = 3.14;
export function Add(x:number,y:number){
    return x + y
}