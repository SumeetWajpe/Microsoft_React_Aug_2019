export default class Product {
    constructor(
        public title?:string,
        public price?:number,
        public rating?:number,
        public ImageUrl?:string,
        public quantity?:number,
        public likes?:number
        ){ }
}
