import React from 'react';
import logo from './logo.svg';
import './App.css';
import { ProductComponent,Add } from './product.component';
import Product from './product.model';

class App extends React.Component {
  products:Product[]=[ new Product("Laptop",60000,4.0),
  new Product("Camera",90000,3.0),
  new Product("Desktop",20000,4.0),
  new Product("Mi Drone",60000,4.0),
  new Product("Go Pro",30000,5.0)
];
  render() {
    var productsToBeCreated = this.products.map(p=>
       <ProductComponent prodDetails={p} />);
    return <div>
        {productsToBeCreated}
    </div>
  }
}

export default App;
