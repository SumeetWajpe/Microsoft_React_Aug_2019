export function users(defStore = [], action: any) {
    switch (action.type) {
        case 'ADD_USER':
            console.log('Within ADD_USER');
            console.log(defStore);// ??

            return defStore;// return updated STore !
        case 'REMOVE_USER':
                console.log('Within REMOVE_USER');
                return defStore;// return updated STore !
    
        default:
            return defStore;
    }
}