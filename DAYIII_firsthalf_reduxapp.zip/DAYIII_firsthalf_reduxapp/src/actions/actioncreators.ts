const INCREMENT_PRODUCT_LIKES = 'INCREMENT_PRODUCT_LIKES';
const DELETE_PRODUCT = 'DELETE_PRODUCT';
const ADD_USER = 'ADD_USER';

export function IncrementProductlikes(theProductId:number){
    return {type:INCREMENT_PRODUCT_LIKES,theProductId};
}

export function DeleteProduct(){
    return {type:DELETE_PRODUCT};
}

export function AddUser(){
    return {type:ADD_USER};
}

export function FetchProducts(){
    return {type:'FETCH_PRODUCTS'};
}