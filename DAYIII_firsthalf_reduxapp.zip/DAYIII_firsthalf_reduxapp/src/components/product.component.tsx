import React from 'react'

export const ProductComponent = (props:any) => {
    return(
        <div>
           {props.prodDetails.title} 
            <button className="btn btn-primary" 
            onClick={()=>props.IncrementProductlikes(props.prodDetails.id)}>
                {props.prodDetails.likes}
            </button> 
           <button className="btn btn-danger" >
               <span className="glyphicon glyphicon-trash">

               </span>
               </button>

        </div>
    )
}

export default ProductComponent;